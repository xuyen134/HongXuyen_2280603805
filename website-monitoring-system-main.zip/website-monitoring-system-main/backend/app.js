require('dotenv').config();
require('express-async-errors');

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const passport = require('./config/passport');
const errorHandler = require('./middlewares/errorHandler');
const authRoutes = require('./routes/authRoutes');
const monitorRoutes = require('./routes/monitorRoutes');
const monitorDetailRoutes = require('./routes/monitorDetailRoutes');
const publicRoutes = require('./routes/publicRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const incidentRoutes = require('./routes/incidentRoutes');
const profileRoutes = require('./routes/profileRoutes');
const apiKeyRoutes = require('./routes/apiKeyRoutes');
const adminRoutes = require('./routes/adminRoutes');
const reportRoutes = require('./routes/reportRoutes');
const teamRoutes = require('./routes/teamRoutes');
const infraRoutes = require('./routes/infraRoutes');

const statusPageRoutes = require('./routes/statusPageRoutes');
const alertRoutes = require('./routes/alertRoutes');
const alertRuleRoutes = require('./routes/alertRuleRoutes');
const maintenanceRoutes = require('./routes/maintenanceRoutes');
const integrationRoutes = require('./routes/integrationRoutes');


const app = express();

// ================== SECURITY MIDDLEWARES ==================
app.use(helmet());
app.use(
  cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    credentials: true, // Cho phép nhận gửi cookies (cần thiết cho auth qua HttpOnly cookie)
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  })
);

// ================== PARSERS MIDDLEWARES ==================
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser()); // Để server có thể đọc parse cookies từ browser gửi lên

// ================== INIT PASSPORT ==================
app.use(passport.initialize());

// ================== ROUTES DEFINITION ==================
app.use('/api/public', publicRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/monitors', monitorRoutes);
app.use('/api/monitors/:id', monitorDetailRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/incidents', incidentRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/api-keys', apiKeyRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/team', teamRoutes);
app.use('/api/infrastructure', infraRoutes);

app.use('/api/status-page', statusPageRoutes);

app.use('/api/alerts', alertRoutes);
app.use('/api/alert-rules', alertRuleRoutes);
app.use('/api/maintenances', maintenanceRoutes);
app.use('/api/integrations', integrationRoutes);


// Fallback 404 Route
app.use((req, res, next) => {
  res.status(404).json({ success: false, message: 'API Endpoint Not Found' });
});

// ================== GLOBAL ERROR HANDLER ==================
app.use(errorHandler);

module.exports = app;
